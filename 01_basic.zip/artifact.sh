cd chipset_qemu/
make
make run