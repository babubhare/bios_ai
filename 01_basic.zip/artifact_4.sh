# Build
make

# Run in QEMU
make run

# Or manually
qemu-system-x86_64 -M q35 -m 128 -bios chipset_init.bin -nographic